#!/usr/bin/python  
#-*-coding:utf-8-*- 
import conf

class Chess():
    """卡牌类"""
    def __init__(self, card):
        self.name = card.name
        self.moral = card.moral
        self.life = card.life
        self.attack = card.attack
        self.index = card.index
        self.move = card.move
        self.isDied = False


    def getInfo(self) :
        return {
            'name' : self.name,
            'moral' : self.moral,
            'life' : self.life,
            'attack' : self.attack,
            'index' : self.index,
            'move': self.move,
            'isDied' : self.isDied
        }
    
    def attackChess(self , chess):
        self.delLife(chess.attack)
        Chess.delLife(self.attack)
       

    def delLife(self , attack) :
        self.life -= attack 
        if self.life < 0 :
            self.life = 0
            self.isDied = True 

    def attackWall(self , user) :
        self.delLife(user.attack)
        user.delLife(self.attack)

